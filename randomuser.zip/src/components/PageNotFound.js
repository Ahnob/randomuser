const PageNotFound = () => {
  return (
    <div>
      <h2>Sorry</h2>
      <p>The page you seek cannot be found</p>
    </div>
  );
};

export default PageNotFound;
